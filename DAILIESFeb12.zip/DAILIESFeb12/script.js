function toggleSwitch() {
  const toggleBtn = document.body;

  toggleBtn.classList.toggle("dark_mode");
}